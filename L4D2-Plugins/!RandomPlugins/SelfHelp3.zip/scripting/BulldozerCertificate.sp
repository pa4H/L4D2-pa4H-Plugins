#include <sourcemod>
#include <sdktools>
#include <selfHelp> // selfHelp.inc

#define TEST_DEBUG			0
#define TEST_DEBUG_LOG		0

static const float UNINCAP_TIME_ON_IMPACT = 1.0;
static const float CHARGE_CHECKING_INTERVAL = 0.4;
static const float CHARGER_COLLISION_RADIUS = 150.0;
static const float HEALTH_SET_DELAY = 0.3;

static const char ENTPROP_HANGING_FROM_LEDGE[] = "m_isHangingFromLedge";
static const char ENTPROP_FALLING_FROM_LEDGE[] = "m_isFallingFromLedge";

static const L4D2_TEAM_SURVIVOR = 2;

static Handle ReinCapTimerArray[MAXPLAYERS + 1];
static bool KillChargerTimer;
static IncappedHealth[MAXPLAYERS + 1];

public Plugin myinfo = 
{
	name = "[L4D2] Bulldozer Certification", 
	author = "AtomicStryker, pa4H", 
	description = "Lets Chargers hit incapped Survivors", 
	version = "1.2", 
	url = "http://forums.alliedmods.net/showthread.php?t=109797"
}

public OnPluginStart()
{
	HookEvent("charger_charge_start", BC_Event_Charge);
	HookEvent("charger_impact", BC_Event_Impact);
	
	HookEvent("charger_charge_end", BC_Event_ChargeEnd);
	HookEvent("charger_killed", BC_Event_ChargeEnd);
	HookEvent("round_end", BC_Event_ChargeEnd);
}

public Action BC_Event_Charge(Handle event, char[] event_name, bool dontBroadcast)
{
	int client = GetClientOfUserId(GetEventInt(event, "userid"));
	if (!client || !IsClientInGame(client)) { return Plugin_Continue; }
	
	KillChargerTimer = false;
	TriggerTimer(CreateTimer(CHARGE_CHECKING_INTERVAL, BC_CheckForIncapped, client, TIMER_REPEAT), true);
	
	DebugPrintToAll("Charge caught, starting ChargerTimer");
	return Plugin_Continue;
}

public Action BC_Event_Impact(Handle event, char[] event_name, bool dontBroadcast)
{
	int target = GetClientOfUserId(GetEventInt(event, "victim"));
	if (ReinCapTimerArray[target] != INVALID_HANDLE)
	{
		CloseHandle(ReinCapTimerArray[target]);
		ReinCapTimerArray[target] = INVALID_HANDLE;
		ReinCapTimerArray[target] = CreateTimer(UNINCAP_TIME_ON_IMPACT * 2, BC_Reincap, target);
		
		DebugPrintToAll("Charger hit a temporary unincapped, extended timer");
	}
	return Plugin_Continue;
}

public Action BC_Event_ChargeEnd(Handle event, char[] event_name, bool dontBroadcast)
{
	KillChargerTimer = true;
	DebugPrintToAll("Charge(r) end caught, killing ChargerTimer");
	CreateTimer(UNINCAP_TIME_ON_IMPACT, BC_WipeHealthArray);
	return Plugin_Continue;
}

public Action BC_CheckForIncapped(Handle timer, any client)
{
	if (!client || !IsClientInGame(client) || KillChargerTimer) {
		KillChargerTimer = false;
		return Plugin_Stop;
	}
	
	float targetpos[3]; float chargerpos[3];
	for (int target = 1; target <= MaxClients; target++)
	{
		if (target == client) { continue; }
		if (!IsClientInGame(target)) { continue; }
		if (GetClientTeam(target) != L4D2_TEAM_SURVIVOR) { continue; }
		if (!IsPlayerIncapped(target)) { continue; }
		if (selfHelp_isHelp(target)) { continue; } // Игрок себе помогает (зажал CTRL)
		if (GetEntProp(target, Prop_Send, ENTPROP_HANGING_FROM_LEDGE) || GetEntProp(target, Prop_Send, ENTPROP_FALLING_FROM_LEDGE)) { continue; }
		
		GetClientAbsOrigin(target, targetpos);
		GetClientAbsOrigin(client, chargerpos);
		
		if (GetVectorDistance(targetpos, chargerpos) < CHARGER_COLLISION_RADIUS)
		{
			DebugPrintToAll("Incapped %N found on way, un-incapping", target);
			
			if (IncappedHealth[target] == -1) {
				IncappedHealth[target] = GetClientHealth(target);
			}
			SetPlayerIncapState(target, false);
			ReinCapTimerArray[target] = CreateTimer(UNINCAP_TIME_ON_IMPACT, BC_Reincap, target);
		}
	}
	return Plugin_Continue;
}

public Action BC_Reincap(Handle timer, any client)
{
	ReinCapTimerArray[client] = INVALID_HANDLE;
	if (!IsValidEntity(client)) { return Plugin_Stop; }
	SetPlayerIncapState(client, true);
	CreateTimer(HEALTH_SET_DELAY, BC_SetHealthDelayed, client);
	DebugPrintToAll("Re-Incapped %N", client);
	
	return Plugin_Stop;
}

public Action BC_SetHealthDelayed(Handle timer, any client)
{
	if (IsValidEntity(client) && IncappedHealth[client] > 1 && IsPlayerIncapped(client)) {
		SetEntityHealth(client, IncappedHealth[client]);
	}
	return Plugin_Stop;
}

public Action BC_WipeHealthArray(Handle timer, any client)
{
	for (int i = 1; i <= MaxClients; i++) {
		IncappedHealth[i] = -1;
	}
	return Plugin_Stop;
}

stock SetPlayerIncapState(int client, any incap)
{
	SetEntProp(client, Prop_Send, "m_isIncapacitated", incap);
}

stock bool IsPlayerIncapped(int client)
{
	if (GetEntProp(client, Prop_Send, "m_isIncapacitated", 1)) { return true; }
	return false;
}

stock DebugPrintToAll(const char[] format, any...)
{
	#if (TEST_DEBUG || TEST_DEBUG_LOG)
	char buffer[256];
	
	VFormat(buffer, sizeof(buffer), format, 2);
	
	#if TEST_DEBUG
	PrintToChatAll("[BULLDOZER] %s", buffer);
	PrintToConsole(0, "[BULLDOZER] %s", buffer);
	#endif
	
	LogMessage("%s", buffer);
	#else
	//suppress "format" never used warning
	if (format[0]) {
		return;
	}
	else {
		return;
	}
	#endif
}

public OnMapEnd()
{
	for (int i = 1; i <= MaxClients; i++) {
		ReinCapTimerArray[i] = INVALID_HANDLE;
	}
} 