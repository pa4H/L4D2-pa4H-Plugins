#include <sourcemod>
#include <colors>
#include <sdktools>
#include <sdkhooks>

Handle cv_TempHP;
Handle cv_BotHelpDelay;
Handle cv_HelpDelay;

Handle cliTimers[MAXPLAYERS + 1];

bool cliIsHelp[MAXPLAYERS + 1]; // Если true, значит игрок себе помогает
float cliTimeToHelp[MAXPLAYERS + 1]; // Таймер для поднятия игрока

public Plugin myinfo = 
{
	name = "Self Help", 
	author = "pa4H", 
	description = "With bot support", 
	version = "2.0", 
	url = "https://t.me/pa4H232"
}

public OnPluginStart()
{
	RegConsoleCmd("sm_test", debb, "");
	
	cv_TempHP = CreateConVar("SelfHelp_TempHP", "100", "");
	cv_BotHelpDelay = CreateConVar("SelfHelp_BotDelay", "6.0", "");
	cv_HelpDelay = CreateConVar("SelfHelp_Delay", "5.0", "");
	
	HookEvent("player_incapacitated", Event_Incap); // Просто инкап
	HookEvent("player_ledge_grab", Event_PlayerLedgeGrab); // Повис
	HookEvent("lunge_pounce", Event_LungePounce); // Охотник
	HookEvent("tongue_grab", Event_TongueGrab); // Язык
	HookEvent("jockey_ride", Event_JockeyRide); // Жокей
	HookEvent("charger_pummel_start", Event_ChargerPummelStart); // Громила
	
	LoadTranslations("pa4H-SelfHelp.phrases.txt");
}

stock Action debb(int client, int args) // DEBUG
{
	//PrintToChatAll(" ");
	//PrintToChatAll("Charger:  %i", GetEntPropEnt(client, Prop_Send, "m_pummelAttacker"));
	//PrintToChatAll("Hunter:  %i", GetEntPropEnt(client, Prop_Send, "m_pounceAttacker"));
	//PrintToChatAll("Jockey:  %i", GetEntPropEnt(client, Prop_Send, "m_jockeyAttacker"));
	//PrintToChatAll("Smoker:  %i", GetEntPropEnt(client, Prop_Send, "m_tongueOwner"));
	//PrintToChatAll("cliTimer:  %i", cliTimers[client]);
	//PrintToChatAll("cliIsHelp (bool):  %i", cliIsHelp[client]);
	//PrintToChatAll("IsNeedHelp (bool):  %i", IsNeedHelp(client));
	
	return Plugin_Handled;
}

public Event_Incap(Handle event, char[] name, bool dontBroadcast) // Просто инкап
{
	int victim = GetClientOfUserId(GetEventInt(event, "userid"));
	checkPlayer(victim);
}

public Event_PlayerLedgeGrab(Handle event, char[] name, bool dontBroadcast) // Повис
{
	int victim = GetClientOfUserId(GetEventInt(event, "userid"));
	checkPlayer(victim);
}

public Event_LungePounce(Handle event, char[] name, bool dontBroadcast) // Охотник
{
	int victim = GetClientOfUserId(GetEventInt(event, "victim"));
	checkPlayer(victim);
}

public Event_TongueGrab(Handle event, char[] name, bool dontBroadcast) // Курильщик
{
	int victim = GetClientOfUserId(GetEventInt(event, "victim"));
	checkPlayer(victim);
}

public Event_JockeyRide(Handle event, char[] name, bool dontBroadcast) // Жокей
{
	int victim = GetClientOfUserId(GetEventInt(event, "victim"));
	checkPlayer(victim);
}

public Event_ChargerPummelStart(Handle event, char[] name, bool dontBroadcast) // Громила
{
	int victim = GetClientOfUserId(GetEventInt(event, "victim"));
	checkPlayer(victim);
}




void checkPlayer(int victim)
{
	if (cliIsHelp[victim]) { return; } // Если клиент уже себе помогает, выходим из функции
	
	if (IsValidBot(victim) && isPlayerHasHelpKit(victim)) {  // Бота инкапнули
		delete cliTimers[victim];
		cliTimers[victim] = CreateTimer(GetConVarFloat(cv_BotHelpDelay), HelpBotTimer, victim);
		return;
	}
	
	if (IsValidClient(victim) && isPlayerHasHelpKit(victim)) {
		CPrintToChat(victim, "%t", "PressBtnChat");
		PrintHintText(victim, "%t", "PressBtnHint");
		delete cliTimers[victim];
		cliTimers[victim] = CreateTimer(0.1, WatchPlayer, victim, TIMER_REPEAT);
	}
}

public Action WatchPlayer(Handle timer, any client)
{
	if (!IsValidClient(client) || !IsNeedHelp(client)) { PrintToChatAll("nohelp"); KillProgressBar(client); cliIsHelp[client] = false; cliTimers[client] = null; return Plugin_Stop; } // Если нас подняли, сбрасываем таймер
	int buttons = GetClientButtons(client);
	if (buttons & IN_DUCK)
	{
		float time = GetEngineTime();
		if (!cliIsHelp[client])
		{
			cliTimeToHelp[client] = time; // Запоминаем время когда начали подниматься
			cliIsHelp[client] = true;
			SetupProgressBar(client, GetConVarFloat(cv_HelpDelay));
		}
		if (cliIsHelp[client]) { if (time - cliTimeToHelp[client] >= GetConVarFloat(cv_HelpDelay)) { cliIsHelp[client] = false; helpPlayer(client); cliTimers[client] = null; return Plugin_Stop; } }
	}
	else
	{
		if (cliIsHelp[client]) {
			cliIsHelp[client] = false;
			KillProgressBar(client);
		}
	}
	return Plugin_Continue;
}

void SetupProgressBar(int client, float time)
{
	SetEntPropFloat(client, Prop_Send, "m_flProgressBarStartTime", GetGameTime());
	SetEntPropFloat(client, Prop_Send, "m_flProgressBarDuration", time);
}

void KillProgressBar(int client)
{
	SetEntPropFloat(client, Prop_Send, "m_flProgressBarStartTime", GetGameTime());
	SetEntPropFloat(client, Prop_Send, "m_flProgressBarDuration", 0.0);
}


public Action HelpBotTimer(Handle timer, any client)
{
	if (!IsNeedHelp(client)) { cliTimers[client] = null; return Plugin_Stop; } // Если бота подняли, сбрасываем таймер
	helpPlayer(client);
	cliTimers[client] = null;
	return Plugin_Stop;
}

bool isPlayerHasHelpKit(int client) // Есть ли у игрока аптечка\таблетки\адрена?
{
	int slotMedKit = GetPlayerWeaponSlot(client, 3);
	int slotPills = GetPlayerWeaponSlot(client, 4);
	if (slotMedKit != -1) { return true; } // Если что-то есть
	if (slotPills != -1) { return true; }
	return false;
}

void helpPlayer(int client)
{
	int attacker = GetAttacker(client)
	if (IsValidAttacker(attacker)) {
		ForcePlayerSuicide(attacker); // У нас есть атакующий, которого надо убить
	}
	
	int reviveCount = GetEntProp(client, Prop_Send, "m_currentReviveCount"); // Сколько раз поднимали клиента? (если 2, то чб)
	reviveCount++;
	
	int iflags = GetCommandFlags("give");
	SetCommandFlags("give", iflags & ~FCVAR_CHEAT);
	FakeClientCommand(client, "give health"); // Поднимаем игрока (выдаем ХП)
	SetCommandFlags("give", iflags);
	
	SetEntProp(client, Prop_Send, "m_currentReviveCount", reviveCount); // + Еще раз подняли
	if (reviveCount >= 2) {
		SetEntProp(client, Prop_Send, "m_bIsOnThirdStrike", 1); // ЧБ 
		SetEntProp(client, Prop_Send, "m_isGoingToDie", 1); // ЧБ
	}
	
	L4D_SetPlayerTempHealth(client, GetConVarInt(cv_TempHP)); // Задаём временные ХП
	SetEntityHealth(client, 1);
	
	eatHelpKit(client); // Убираем из инвентаря аптеку или таблы
	
	PrecacheSound("ui/littlereward.wav");
	EmitSoundToClient(client, "ui/littlereward.wav");
}

stock void L4D_SetPlayerTempHealth(int client, int tempHealth)
{
	SetEntPropFloat(client, Prop_Send, "m_healthBuffer", float(tempHealth));
	SetEntPropFloat(client, Prop_Send, "m_healthBufferTime", GetGameTime());
}

void eatHelpKit(int client) // Убираем из инвентаря предмет
{
	int slotMedKit = GetPlayerWeaponSlot(client, 3);
	if (slotMedKit != -1) { RemovePlayerItem(client, slotMedKit); return; }
	
	int slotPills = GetPlayerWeaponSlot(client, 4); // Если аптечки нет, удаляем таблы
	if (slotPills != -1) { RemovePlayerItem(client, slotPills); return; }
}

stock bool Contains(const char[] one, const char[] two)
{
	if (StrContains(one, two, false) != -1) { return true; } else { return false; }
}
stock bool IsValidClient(client)
{
	if (client > 0 && client <= MaxClients && IsClientInGame(client) && IsClientConnected(client) && !IsFakeClient(client)) {
		return true;
	}
	return false;
}
stock bool IsValidBot(client)
{
	if (client > 0 && client <= MaxClients && IsClientInGame(client) && IsClientConnected(client) && IsFakeClient(client)) {
		return true;
	}
	return false;
}

bool IsNeedHelp(int client) {
	if (GetEntProp(client, Prop_Send, "m_isIncapacitated")) { return true; }
	if (GetEntPropEnt(client, Prop_Send, "m_tongueOwner") > 0 || GetEntPropEnt(client, Prop_Send, "m_jockeyAttacker") > 0 || GetEntPropEnt(client, Prop_Send, "m_pounceAttacker") > 0 || GetEntPropEnt(client, Prop_Send, "m_pummelAttacker") > 0) {
		return true;
	}
	return false;
}

int GetAttacker(int victim)
{
	int attacker;
	attacker = GetEntPropEnt(victim, Prop_Send, "m_tongueOwner");
	if (IsValidAttacker(attacker)) { return attacker; }
	attacker = GetEntPropEnt(victim, Prop_Send, "m_jockeyAttacker");
	if (IsValidAttacker(attacker)) { return attacker; }
	attacker = GetEntPropEnt(victim, Prop_Send, "m_pounceAttacker");
	if (IsValidAttacker(attacker)) { return attacker; }
	attacker = GetEntPropEnt(victim, Prop_Send, "m_pummelAttacker");
	if (IsValidAttacker(attacker)) { return attacker; }
	return 0;
}

bool IsValidAttacker(int attacker)
{
	if (attacker > 0 && IsClientInGame(attacker) && GetClientTeam(attacker) == 3 && IsPlayerAlive(attacker)) { return true; }
	return false;
}

public OnMapEnd()
{
	for (int i = 1; i <= MaxClients; i++) {
		delete cliTimers[i];
		cliIsHelp[i] = false;
	}
}

public APLRes AskPluginLoad2(Handle myself, bool late, char[] error, int err_max)
{
	CreateNative("selfHelp_isHelp", Native_isHelp); // selfHelp.inc
	return APLRes_Success;
}

public Native_isHelp(Handle plugin, int numParams)
{
	return cliIsHelp[GetNativeCell(1)];
}
