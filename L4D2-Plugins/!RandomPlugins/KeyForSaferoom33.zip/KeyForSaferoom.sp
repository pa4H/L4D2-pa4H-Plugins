#include <sourcemod>
#include <colors>
#include <left4dhooks>
#include <sdktools>
#include <sdkhooks>

#define LOCK 1
#define UNLOCK 0

int keyMan;
static float doorCooldown = 0.0;
int saferoomEnt = -1;
bool isDoorTouch = false;
bool roundStarted = false;

public Plugin myinfo = 
{
	name = "KeyForSaferoom", 
	author = "pa4H, finishlast", 
	description = "Gives a random player a key that opens the saferoom", 
	version = "3.3", 
	url = "https://t.me/pa4H232"
}

public OnPluginStart()
{
	//RegConsoleCmd("sm_test", debb, "");
	RegConsoleCmd("sm_givek", giveKeyMenu, "");
	RegConsoleCmd("sm_cl", whereKey, "");
	
	HookEvent("versus_round_start", VersusRoundStart_Event, EventHookMode_Pre);
	HookEvent("round_end", RoundEnd_Event, EventHookMode_PostNoCopy);
	HookEvent("player_use", PlayerUse_Event, EventHookMode_Pre);
	HookEvent("player_disconnect", PlayerDisconnect_Event, EventHookMode_Pre);
	HookEvent("player_team", ChangeTeam_Event, EventHookMode_Pre);
	HookEvent("player_death", Event_PlayerDeath, EventHookMode_Post);
	
	LoadTranslations("KeyForSaferoom.phrases");
}
stock Action debb(int client, int args) // DEBUG
{
	
	return Plugin_Handled;
}

public void VersusRoundStart_Event(Event hEvent, const char[] sEvName, bool bDontBroadcast) // Срабатывает после выхода из saferoom
{
	doorCooldown = 0.0;
	CreateTimer(1.5, roundStartTimer);
}
public Action roundStartTimer(Handle timer)
{
	roundStarted = true;
	if (allBotsSur()) {
		ControlDoor(UNLOCK);
		CPrintToChatAll("%t", "AllBots");
		return Plugin_Stop;
	}
	giveKeyRandom(); // Выдаём ключ рандомному игроку
	return Plugin_Stop;
}

void giveKeyRandom(int disClient = 0) // disClient - клиент, которого не учитываем в выдаче ключа
{
	int rand = 0;
	int survivors[MAXPLAYERS];
	int ii = 0;
	for (int i = 1; i < MAXPLAYERS; i++)
	{
		if (IsValidClient(i) && GetClientTeam(i) == 2 && IsPlayerAlive(i) && i != disClient) {
			survivors[ii] = i;
			ii++;
		}
	}
	rand = GetRandomInt(0, ii - 1);
	keyMan = survivors[rand];
	
	ControlDoor(LOCK);
	CPrintToChatAll("%t", "Randomkey", keyMan);
}

public Action PlayerDisconnect_Event(Handle event, const char[] name, bool dontBroadcast)
{
	int client = GetClientOfUserId(GetEventInt(event, "userid")); // Получаем номер клиента
	if (client == keyMan && IsValidClient(client)) {
		if (allBotsSur() || countSur() - 1 == 0) {
			ControlDoor(UNLOCK);
			CPrintToChatAll("%t", "AllBots");
			return Plugin_Continue;
		}
		giveKeyRandom(client); // Выдаём рандомному игроку кроме выходящего с сервера
	}
	return Plugin_Continue;
}
public void Event_PlayerDeath(Event event, const char[] name, bool dontBroadcast)
{
	int victim = GetClientOfUserId(event.GetInt("userid"));
	
	if (victim > 0 && victim <= MaxClients && IsClientInGame(victim) && IsClientConnected(victim)) {  } else { return; }
	
	if (GetClientTeam(victim) == 2) {
		int c = 0;
		for (int i = 1; i < MaxClients; i++)
		{
			if (IsClientConnected(i) && IsClientInGame(i) && GetClientTeam(i) == 2 && IsPlayerAlive(i)) { c++; }
		}
		PrintHintTextToAll("%t", "SurvDead", victim, c);
	}
	
	if (!IsFakeClient(victim) && victim == keyMan && GetClientTeam(victim) == 2)
	{
		if (countSur() > 1) {  // Если есть игроки
			giveKeyRandom(victim);
		}
	}
	
	
}

public Action ChangeTeam_Event(Handle event, const char[] name, bool dontBroadcast)
{
	if (!roundStarted) { return Plugin_Continue; }
	
	int client = GetClientOfUserId(GetEventInt(event, "userid"));
	int newTeam = GetEventInt(event, "team");
	int oldTeam = GetEventInt(event, "oldteam");
	
	if (IsValidClient(client)) {
		if (newTeam == 2 && countSur() == 0) {  // Перешли к выжившим где все боты
			//PrintToChatAll("1 %i", countSur());
			keyMan = client;
			CPrintToChatAll("%t", "Randomkey", keyMan);
			ControlDoor(LOCK);
			return Plugin_Continue;
		}
		if ((newTeam == 3 || newTeam == 1) && oldTeam == 2 && countSur() - 1 == 0) {  // Перешли к зараженным если за людей боты
			//PrintToChatAll("2 countsur:%i", countSur());
			keyMan = 999;
			ControlDoor(UNLOCK);
			CPrintToChatAll("%t", "AllBots");
			return Plugin_Continue;
		}
		if ((newTeam == 3 || newTeam == 1) && keyMan == client) {  // У переходящего есть ключ. Он перешел к зараженным
			//PrintToChatAll("3 %i", countSur());
			giveKeyRandom(client); // Даём ключ рандомному игроку исключая клиента, который меняет тиму
			return Plugin_Continue;
		}
	}
	return Plugin_Continue;
}

public Action PlayerUse_Event(Event event, const char[] name, bool dontBroadcast)
{
	if (isDoorTouch) { return Plugin_Continue; }
	int used = event.GetInt("targetid");
	int client = GetClientOfUserId(GetEventInt(event, "userid"));
	if (IsValidEnt(used))
	{
		char sEntityClass[64];
		GetEdictClassname(used, sEntityClass, sizeof(sEntityClass));
		if (doorCooldown > GetGameTime() || !StrEqual(sEntityClass, "prop_door_rotating_checkpoint") || EntIndexToEntRef(used) != saferoomEnt)
		{
			return Plugin_Continue;
		}
		else
		{
			doorCooldown = GetGameTime() + 0.5;
			if (L4D2_IsTankInPlay() && client != keyMan) {
				CPrintToChat(client, "%t", "TankNoKey", keyMan);
				return Plugin_Continue;
			}
			if (L4D2_IsTankInPlay() && client == keyMan) {
				CPrintToChat(client, "%t", "TankKey");
				return Plugin_Continue;
			}
			if (!L4D2_IsTankInPlay() && client != keyMan) {
				CPrintToChat(client, "%t", "NoKey", keyMan);
				return Plugin_Continue;
			}
			if (!L4D2_IsTankInPlay() && client == keyMan) {
				CPrintToChatAll("%t", "Welcome");
				ControlDoor(UNLOCK);
				isDoorTouch = true;
				return Plugin_Continue;
			}
		}
	}
	return Plugin_Continue;
}
void findDoor()
{
	char targetname[20];
	int founddoor = 0;
	int entity = -1;
	while ((entity = FindEntityByClassname(entity, "prop_door_rotating_checkpoint")) != -1)
	{
		GetEntPropString(entity, Prop_Data, "m_iName", targetname, sizeof(targetname));
		
		if (StrEqual(targetname, "checkpoint_entrance"))
		{
			saferoomEnt = EntIndexToEntRef(entity);
			founddoor = 1;
			break;
		}
	}
	
	char sModel[64];
	if (founddoor == 0)
	{
		while ((entity = FindEntityByClassname(entity, "prop_door_rotating_checkpoint")) > -1)
		{
			if (IsValidEntity(entity))
			{
				GetEntPropString(entity, Prop_Data, "m_ModelName", sModel, sizeof(sModel));
				
				if (StrContains(sModel, "checkpoint_door") > -1 && StrContains(sModel, "02") > -1)
				{
					saferoomEnt = EntIndexToEntRef(entity);
					break;
				}
			}
		}
	}
}

void ControlDoor(int mode)
{
	findDoor();
	if (!IsValidEntity(saferoomEnt)) { return; }
	
	if (mode == LOCK)
	{
		isDoorTouch = false;
		AcceptEntityInput(saferoomEnt, "Close");
		AcceptEntityInput(saferoomEnt, "Lock");
		AcceptEntityInput(saferoomEnt, "ForceClosed");
		SetEntProp(saferoomEnt, Prop_Data, "m_hasUnlockSequence", LOCK);
	}
	else if (mode == UNLOCK)
	{
		SetEntProp(saferoomEnt, Prop_Data, "m_hasUnlockSequence", UNLOCK);
		AcceptEntityInput(saferoomEnt, "Unlock");
		AcceptEntityInput(saferoomEnt, "ForceClosed");
		//AcceptEntityInput(saferoomEnt, "Open");
	}
}
Action giveKeyMenu(int client, int args)
{
	if (keyMan == 0) {
		CPrintToChatAll("%t", "NotStarted");
		return Plugin_Handled;
	}
	if (client != keyMan) {
		CPrintToChatAll("%t", "NoKey", keyMan);
		return Plugin_Handled;
	}
	
	char clName[32];
	char clNum[4];
	
	Menu menu = new Menu(Menu_GiveKey);
	menu.SetTitle("%T", "Sharekey", client);
	for (int i = 1; i < MaxClients; i++)
	{
		if (IsValidClient(i) && GetClientTeam(i) == 2 && i != client) {
			GetClientName(i, clName, sizeof(clName));
			FormatEx(clNum, sizeof(clNum), "%i", i);
			menu.AddItem(clNum, clName);
		}
	}
	menu.Display(client, 15);
	return Plugin_Handled;
}
public Menu_GiveKey(Menu menu, MenuAction action, int client, int param2)
{
	if (action == MenuAction_Select)
	{
		char szInfo[4];
		menu.GetItem(param2, szInfo, sizeof(szInfo));
		int newKeyMan = StringToInt(szInfo);
		if (IsValidClient(newKeyMan)) {
			keyMan = newKeyMan;
			CPrintToChat(keyMan, "%t", "Getkey"); // Вам передали ключ
			CPrintToChat(client, "%t", "Sendkey", keyMan); // Вы передали ключ игроку ?
		}
		
	}
}
Action whereKey(int client, int args)
{
	if (keyMan == 0) {
		CPrintToChatAll("%t", "NotStarted");
	}
	else if (keyMan > 0 && IsValidClient(keyMan)) {
		CPrintToChatAll("%t", "Wherekey", keyMan);
	}
	else if (keyMan == 999)
	{
		CPrintToChatAll("%t", "AllBots");
	}
	return Plugin_Handled;
}
stock bool allBotsSur()
{
	int c = 0;
	for (int i = 1; i < MaxClients; i++)
	{
		if (IsValidClient(i) && GetClientTeam(i) == 2) { c++; }
	}
	if (c > 0) { return false; }
	return true;
}
stock int countSur()
{
	int c = 0;
	for (int i = 1; i < MaxClients; i++)
	{
		if (IsValidClient(i) && GetClientTeam(i) == 2) { c++; }
	}
	
	return c;
}
stock bool IsValidClient(client)
{
	if (client > 0 && client <= MaxClients && IsClientInGame(client) && IsClientConnected(client) && !IsFakeClient(client)) {
		return true;
	}
	return false;
}
bool IsValidEnt(int entity)
{
	return (entity > 0 && IsValidEntity(entity) && IsValidEdict(entity));
}
public void OnMapEnd()
{
	doorCooldown = 0.0;
	keyMan = 0;
	roundStarted = false;
}

public void RoundEnd_Event(Event event, const char[] name, bool dontBroadcast)
{
	doorCooldown = 0.0;
	keyMan = 0;
	roundStarted = false;
} 